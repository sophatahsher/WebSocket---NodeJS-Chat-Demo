var WebSocketServer = require('ws').Server;

var PORT    = process.env.PORT || 8087;
var wss     = new WebSocketServer({port: PORT});

// MYSQL
var mysql   = require('mysql');

var dbConfig = {
    host    : "localhost",
    user    : "root",
    password: "123456",
    database: "chat_db",
    connectionLimit: 2,
    queueLimit: 0,
    waitForConnection: true
};
var connection = mysql.createPool(dbConfig);

var messages = [];
wss.on('connection', function (ws)
{
    messages.forEach(function(message){
        ws.send(message);
    });

    ws.on('message', function (message)
    {
        messages.push(message);
        console.log('Message Received: %s', message);

        // save to db
        var now         = new Date();
        var jsonDate    = now.toJSON();
        var dateTime    = new Date(jsonDate);

        var data        = JSON.parse(message);
        var userMessage = { user_name: data['user'] , message: data['text'], datetime: dateTime };

        var sql         = "INSERT INTO tbl_messages SET ?";
        connection.query(sql, userMessage, function (err, result) {
            if (err) throw err;
            console.log("1 record inserted");
        });

        wss.clients.forEach(function (conn)
        {
            conn.send(message);
        });
    });

});

